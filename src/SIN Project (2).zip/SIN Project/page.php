<html>
<head>
<title>
</title>

</head>
<style>
body{
background-image:url("rainfall1.jpg");
height:110vh;
	background-size:cover;
	background-position:center;
}
#ALL{
width:50px;
background-color:grey;
}

.btn{
position:top;
width:300px
top:2px;
border:2px solid black;
}
ul
{
 float:left;
 list-style-type:none;
 margin-top:20px
}
ul li{
 display:inline-block;
 color:white;
}
ul li a{
 text-decoration:none;
 color:White;
 padding:10px 30px;
 border:1px solid transparent;
 transition:0.6s;
}
ul li a:hover{
 background-color:orange;
 color:white;
}
ul li active{
 background-color:green;
 color:black;
}
 #nav-packard-glow-loc-icon{
    position: absolute;
    width: 22px;
    height: 22px;
    background-position: -68px -340px;
    left: 2px;
    top: 8px;
}
#para {
  position: relative;
  top:30px;
  margin: 5% auto;
  width: 500px;
  height: 550px;
  background: transparent;
  border-radius: 2px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.4);
  color:white;
}


</style>
<body>
<div class="nav-sprite" id="nav-packard-glow-loc-icon">HELLO</div>
<center>

</center>
<center>
<ul>

<li><a href="index4.html">RAINFALL PREDICTION</a></li>
<li><a href="https://mausam.imd.gov.in/imd_latest/contents/index_rainfall_state_new.php">DETAILS OF RAINFALL</a></li>
<li><a href="rainfall youtube model.php">VIDEOS</a></li>
<li><a href="news and updates.php">LINKS FOR NEWS AND UPDATES</a></li>
<li><a href="contact.html">CONTACT US</a></li>
<li><a href="help.html">HELP</a></li>
<hr>
 
 </ul>
 
</center>
 <center>
 <p id="para">
 HERE IS THE RAINFALL PREDICTION WEBSITE USED FOR THE PREDICTING THE RAINFALL
 
 </p>
 
 </center>
 <div id="a">
 </div>
  <div id="b">
 </div>
 <div id="c">
 </div>
 
</body>
</html>

