<html>
<head>
<title>
</title>
<style>

.button:hover{
cursor:pointer;
color:white;
background-color:orange;
border-bottom:5px;
border-size:10px;
padding:5px;
transition:3sec; 
}
.or:hover{
cursor:pointer;
color:white;
background-color:orange;
border-bottom:5px;
border-size:10px;
padding:5px;
transition:3sec; 
}

</style>

</head>
<body bgcolor="white">

<div class="button" href="https://www.youtube.com/embed=gzqrnqFRfb8">Home</div>
</div>
<br>
<div class="or">Trendings</div>
</div>
<br>
<div class="or">Subscriptions</div>
</div>
<br><hr>
<div class="or">Library</div>
</div>
<br>
<div class="or">History</div>
</div>
<br><hr>
<div class="or">Your videos</div>
</div>
<br>
<div class="or">Watch Later</div>
</div>
<br>
<div class="or">Liked videos</div>
</div>
<br><hr>
<div class="or">Settings</div>
</div><br>
<div class="or">Your Account</div>
</div>



</body>
</html>
