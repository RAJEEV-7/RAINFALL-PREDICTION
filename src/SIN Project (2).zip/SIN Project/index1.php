<html>
<head>
<title>Comparision</title>
</head>

<frameset cols="50%,50%">
<frame src="index2.html" Scrolling="yes">
<frame src="index.html" Scrolling="auto">




</frameset>
<body>

</body>


</html>
