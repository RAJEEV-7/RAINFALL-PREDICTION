<html>
<head>
<title>
</title>
<style>
 .or {
  position: absolute;
  top: 1px;
  left: 720px;
  width: 40px;
  height: 40px;
  background: orange;
  border-radius: 50%;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.4);
  line-height: 40px;
  text-align: center;
  cursor:pointer;
}
</style>

</head>
<body bgcolor="white">
<div class="or">VSP</div>
</div>
<center>
<input type="search" placeholder="Search" name="search" id="search" style="width:500px;padding:2px;position:top">
<input type="button" name="btn" id="btn" style="width:10px;height:20px;position:relative" ><hr>

</center>
<iframe width="770" height="500" src="https://www.youtube.com/embed/gzqrnqFRfb8">
</iframe><br>
<br>
<br>

Comments<br>
<input type="text" name="comments" id="comments" style="font-family:sans-serif;font-size:1.2em;width:1000px;height:500px"/>
<input type="submit" name="submit" class="submit">
</body>
</html>
